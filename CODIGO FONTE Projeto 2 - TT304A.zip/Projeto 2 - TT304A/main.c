#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>
#include <stdint.h>
#include <time.h>
#include <math.h>
#include <semaphore.h>

#include <pthread.h>

#define cstdint

//Função responsavel por ler os numeros inteiros dos arquivos
/**
 * @Param nome - Nome do arquivo
 * @Param tamanho - Quantidade de numeros inteiros no arquivo
 * 
 * @Return Essa retorna os numeros inteiros em um vetor 
*/
int *leArquivo(char *nome, int *tamanho);

//Função responsavel por organizar as threads. Essa função decide quais ações cada thread ira realizar
/**
 * @Param ptr - Estruta ThreadAtributo que contem as informações da thread em execução para a função decidir as ações a thread deve tomar
 * Essa função:
 * - Divide as Linhas de numeros inteiros a serem ordenados em N blocos, onde N = quantide de numeros inteiros na Linha / Numero de threads 
 * - Decide qual bloco a thread sera responsavel por organizar
 * -------------------------------------
 * Após ordenar os blocos esta função decide quais threads irão JUNTAR os blocos e quais serão finalizadas
 * Função ultilizada para JUNTAR os blocos ->  emergindo(void *ptr, int nt)
 */
void *organizar(void *ptr);

//Função equivalente ao terceiro passo do algorimo Merge Sort -  Combinação / Fundir
/**
 *@Param ptr - Estruta ThreadAtributo que contem as informações da thread em execução para a função decidir as ações a thread deve tomar
 *@Param nt - Numero de threads que ainda estão em execução
 * Essa função junta 2 Blocos de numeros inteiros ordenados em 1 bloco de numeros inteiros ordenados
 */
void emergindo(void *ptr, int nt);

//Algorotimo BubbleSort para ordenação de vetores em ordem crescente
/**
 *@Param vetor  - Vetor onde estão os numeros inteiros a serem ordenados
 *@Param inicio - Posição inicial do vetor 
 *@Param fim    - Posição final do vetor
 * Essa função somente ordena os numeros inteiro que estão entre a posição inicial e final do vetor
 */
void BubbleSort(int *vetor, int inicio, int fim);

//Função responsavel por salvar a matriz (Linhas de numeros inteiros) em um arquivo
/**
 *@Param nome - Nome do arquivo onde sera salvo os dados 
 *@Param maiorTamanho - quantidade de numeros inteiros do arquivo com mais numeros inteiros
 */
void salvarArquivo(char *nome, int maiorTamanho);

typedef struct threadAtributo
{
    int meuNumero;  //Numero da thread
    pthread_t id;   //Id da thread
    int prioridade; //Prioridade da thread - Quando o valor é zero a thread é encerrada
    int parte;      //Numero do bloco que a thread eh responsavel por organizar
} ThreadAtributo;

char **nome;      //Nome dos arquivos de entrada
int **matriz;     //Matriz onde é salvo os numeros inteiros
int *tamanho;     //Quantidade de numeros inteiros em cada linha da matriz
int qntdArquivos; //Quantidade de arquivos de entrada
int numThread;    //Numero de threads do programa

sem_t semafaro; // Semaforo responsavel por garantir que todas as threads sejam criadas antes que algumas delas iniciem sua execução

//Vetor de ThreadAtributo que contem informações de todas as threads
ThreadAtributo **taGlobal;

int main(int argc, const char *argv[])
{

    char saida[20]; //Variavel que armazena nome do arquivo de saida
    clock_t t1, t2; //Variavel para contar o tempo de execução do programa

    qntdArquivos = argc - 4;
    matriz = (int **)malloc(sizeof(int *) * qntdArquivos);
    tamanho = (int *)malloc(sizeof(int *) * qntdArquivos);

    //Arquivos de entrada
    nome = (char **)malloc(sizeof(char *) * qntdArquivos);
    for (int i = 0; i < qntdArquivos; i++)
    {
        nome[i] = (char *)malloc(sizeof(char) * 20);
    }
    printf("Quantidade Arquivos de entrada : %d\n", qntdArquivos);
    for (int aux = 2; aux < argc - 2; aux++)
    {
        strcpy(nome[aux - 2], argv[aux]);
        printf("Arquivo %d : %s\n", aux - 1, nome[aux - 2]);
    }

    //Arquivo de saida
    strcpy(saida, argv[argc - 1]);
    printf("Saida : %s\n", saida);

    //Numero de threads
    uintmax_t nT = strtoumax(argv[1], NULL, 10);
    numThread = nT;
    printf("Quantidade de Thread %d\n", numThread);

    //Leitura dos arquivos de entradas
    for (int a = 0; a < qntdArquivos; a++)
    {
        matriz[a] = leArquivo(nome[a], &tamanho[a]);
    }

    //Criação das estruturas ThreadAtributo de cada Thread
    taGlobal = (ThreadAtributo **)malloc(sizeof(ThreadAtributo *) * numThread);
    for (int i = 0; i < numThread; i++)
    {
        taGlobal[i] = (ThreadAtributo *)malloc(sizeof(ThreadAtributo));
    }

    //Atribuição de valores nas estruturas ThreadAtributo de cada Thread
    for (int i = 0; i < numThread; i++)
    {
        if ((numThread - i) % 2 == 0)
        {
            taGlobal[i]->prioridade = (numThread - i) / 2;
        }
        else
        {
            taGlobal[i]->prioridade = 0;
        }
        taGlobal[i]->parte = i + 1;
        taGlobal[i]->meuNumero = i + 1;
    }

    //Inicio da contagem de tempo
    t1 = clock();

    //Criação das threads
    sem_init(&semafaro, 0, 0);
    for (int i = 0; i < numThread; i++)
    {
        pthread_create(&taGlobal[i]->id, NULL, organizar, (void *)taGlobal[i]);
    }
    for (int i = 0; i < numThread; i++)
        sem_post(&semafaro);

    //Fim das execuções das Threads
    pthread_join(taGlobal[0]->id, NULL);

    //Fim da contagem de tempo
    t2 = clock();

    //Busca pelo maiorTamanho
    int maiorTamanho = 0;
    for (int i = 0; i < qntdArquivos; i++)
    {
        if (tamanho[i] > maiorTamanho)
            maiorTamanho = tamanho[i];
    }

    //Salvando dados no arquivo de saida
    salvarArquivo(saida, maiorTamanho);

    printf("\nTempo de execução : %f", (t2 - t1) / (double)CLOCKS_PER_SEC);
    getchar();

    return 0;
}

void *organizar(void *ptr)
{
    ThreadAtributo *ta = (ThreadAtributo *)ptr;

    int nt = numThread;

    sem_wait(&semafaro);

    for (int linha = 0; linha < qntdArquivos; linha++)
    {
        int inicio = ((ta->parte - 1) * tamanho[linha] / nt);
        int fim = (ta->parte * tamanho[linha] / nt);
        BubbleSort(matriz[linha], inicio, fim);
    }

    while (ta->prioridade != 0)
    {
        if (((ta->meuNumero - 1) + (numThread / nt)) <= (numThread - 1))
        {

            if (ta->prioridade > taGlobal[((ta->meuNumero - 1) + (numThread / nt))]->prioridade)
            {

                pthread_join(taGlobal[((ta->meuNumero - 1) + (numThread / nt))]->id, NULL);
                int parte = ta->parte;
                ta->parte = (taGlobal[((ta->meuNumero - 1) + (numThread / nt))]->parte) / 2;

                nt /= 2;

                emergindo((void *)ta, nt);

                if ((ta->parte % 2 == 0) || (nt == 1))
                {
                    ta->prioridade = 0;
                }
            }
        }
        else
        {
            ta->prioridade = 0;
        }
    }

    pthread_exit(NULL);
}

void emergindo(void *ptr, int nt)
{
    ThreadAtributo *ta = (ThreadAtributo *)ptr;

    for (int linha = 0; linha < qntdArquivos; linha++)
    {
        int comeco = (ta->parte - 1) * (tamanho[linha] / nt);
        int fim = (ta->parte * (tamanho[linha] / nt)) - 1;
        int meio = (fim + comeco) / 2;

        int com1 = comeco;
        int com2 = meio + 1;
        int comAux = 0;
        int tam = fim - comeco;
        int *vetAux;

        vetAux = (int *)malloc(tam * sizeof(int));

        while (com1 <= meio && com2 <= fim)
        {

            if (matriz[linha][com1] < matriz[linha][com2])
            {

                vetAux[comAux] = matriz[linha][com1];

                com1++;
            }
            else
            {

                vetAux[comAux] = matriz[linha][com2];

                com2++;
            }

            comAux++;
        }

        while (com1 <= meio)
        { //Caso ainda haja elementos na primeira metade

            vetAux[comAux] = matriz[linha][com1];

            comAux++;

            com1++;
        }

        while (com2 <= fim)
        { //Caso ainda haja elementos na segunda metade

            vetAux[comAux] = matriz[linha][com2];

            comAux++;

            com2++;
        }

        for (comAux = comeco; comAux <= fim; comAux++)
        { //Move os elementos de volta para o vetor original

            matriz[linha][comAux] = vetAux[comAux - comeco];
        }
        free(vetAux);
    }
}

void BubbleSort(int *vetor, int inicio, int fim)
{

    int k, j, aux;

    for (k = 1; k < fim; k++)
    {

        for (j = inicio; j < fim - 1; j++)
        {
            if (vetor[j] > vetor[j + 1])
            {
                aux = vetor[j];
                vetor[j] = vetor[j + 1];
                vetor[j + 1] = aux;
            }
        }
    }
}

void salvarArquivo(char *nome, int maiorTamanho)
{
    FILE *f;

    f = fopen(nome, "w+");
    fseek(f, 0, SEEK_SET);
    for (int i = 0; i < qntdArquivos; i++)
    {
        for (int j = 0; j < maiorTamanho; j++)
        {
            if (j < tamanho[i])
            {
                fprintf(f, "%03d ", matriz[i][j]);
            }
            else
            {
                fprintf(f, "%03d ", 0);
            }
        }
        fprintf(f, "\n");
    }
    fclose(f);
}

int *leArquivo(char *nome, int *tamanho)
{

    FILE *f;
    int aux = 0;

    f = fopen(nome, "r+");

    while (fscanf(f, "%*d") != EOF)
    {
        aux++;
    }

    int *vetor = (int *)malloc(sizeof(int) * aux);
    *tamanho = aux;
    aux = 0;
    rewind(f);
    while (fscanf(f, "%d", &vetor[aux]) != EOF)
    {
        aux++;
    }

    fclose(f);
    return vetor;
}
